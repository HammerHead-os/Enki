(function () {
  'use strict';

  /* ─────────────────────────────────────────
     1. VIGNETTE — darkness that breathes
  ───────────────────────────────────────── */
  var vignette = document.createElement('div');
  vignette.style.cssText = [
    'position:fixed', 'top:0', 'left:0', 'width:100%', 'height:100%',
    'pointer-events:none', 'z-index:9980',
    'background:radial-gradient(ellipse at 50% 50%, transparent 42%, rgba(0,0,0,0.72) 100%)'
  ].join(';');
  document.body.appendChild(vignette);

  (function breathe() {
    var t = Date.now() * 0.00035;
    var scale = 42 + Math.sin(t) * 5;
    vignette.style.background =
      'radial-gradient(ellipse at 50% 50%, transparent ' + scale.toFixed(1) + '%, rgba(0,0,0,0.72) 100%)';
    requestAnimationFrame(breathe);
  })();


  /* ─────────────────────────────────────────
     2. CURSOR TRAIL — dark smear, no dots
  ───────────────────────────────────────── */
  var trailCanvas = document.createElement('canvas');
  trailCanvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9979';
  document.body.appendChild(trailCanvas);
  var tCtx = trailCanvas.getContext('2d');
  var tw, th;
  function resizeTrail() {
    tw = trailCanvas.width = window.innerWidth;
    th = trailCanvas.height = window.innerHeight;
  }
  resizeTrail();
  window.addEventListener('resize', resizeTrail);

  var mouseX = -999, mouseY = -999, lastMX = -999, lastMY = -999;
  document.addEventListener('mousemove', function (e) { mouseX = e.clientX; mouseY = e.clientY; });

  (function fadeTrail() {
    tCtx.globalCompositeOperation = 'destination-in';
    tCtx.fillStyle = 'rgba(0,0,0,0.94)';
    tCtx.fillRect(0, 0, tw, th);
    tCtx.globalCompositeOperation = 'source-over';
    if (mouseX !== lastMX || mouseY !== lastMY) {
      tCtx.beginPath();
      tCtx.arc(mouseX, mouseY, 1.8, 0, Math.PI * 2);
      tCtx.fillStyle = 'rgba(90,0,0,0.32)';
      tCtx.fill();
      lastMX = mouseX; lastMY = mouseY;
    }
    requestAnimationFrame(fadeTrail);
  })();


  /* ─────────────────────────────────────────
     3. SUBLIMINAL TEXT — barely readable,
        like thoughts you cannot suppress
  ───────────────────────────────────────── */
  var messages = [
    'you agreed to this',
    'they already know',
    'consent was implied',
    'you cannot opt out',
    'your silence is data',
    'the algorithm knows before you do',
    'you are the product',
    'there is no delete',
    'they kept a copy',
    'your face has been logged',
    'attention is the commodity',
    'someone is reading this',
  ];

  function showSubtext() {
    var el = document.createElement('div');
    el.textContent = messages[Math.floor(Math.random() * messages.length)];
    var size = 1.0 + Math.random() * 0.9;
    el.style.cssText = [
      'position:fixed',
      'pointer-events:none',
      'z-index:9985',
      'font-family:"Share Tech Mono",monospace',
      'font-size:' + size + 'rem',
      'color:rgba(200,200,210,0)',
      'white-space:nowrap',
      'letter-spacing:0.07em',
      'top:' + (8 + Math.random() * 84) + '%',
      'left:' + (4 + Math.random() * 60) + '%',
      'transform:rotate(' + (Math.random() * 2 - 1) + 'deg)',
      'transition:color 2.8s ease, opacity 2.5s ease',
      'opacity:0',
    ].join(';');
    document.body.appendChild(el);
    requestAnimationFrame(function () {
      el.style.color = 'rgba(190,175,185,0.08)';
      el.style.opacity = '1';
    });
    setTimeout(function () {
      el.style.color = 'rgba(200,200,210,0)';
      el.style.opacity = '0';
    }, 4000);
    setTimeout(function () { el.remove(); }, 7000);
    setTimeout(showSubtext, 7500 + Math.random() * 11000);
  }
  setTimeout(showSubtext, 10000);


  /* ─────────────────────────────────────────
     4. SCROLL DARKNESS — room with no windows
  ───────────────────────────────────────── */
  window.addEventListener('scroll', function () {
    var pct = window.scrollY / (document.body.scrollHeight - window.innerHeight);
    var r = Math.round(12 + pct * 6);
    var g = Math.round(12 - pct * 5);
    var b = Math.round(16 - pct * 7);
    document.body.style.backgroundColor = 'rgb(' + r + ',' + g + ',' + b + ')';
  }, { passive: true });


  /* ─────────────────────────────────────────
     5. JUMP SCARE — once, deep in page,
        a single frame of eyes in darkness.
        Gone before you're certain you saw it.
  ───────────────────────────────────────── */
  var scaredOnce = false;
  window.addEventListener('scroll', function () {
    if (scaredOnce) return;
    var pct = window.scrollY / (document.body.scrollHeight - window.innerHeight);
    if (pct < 0.74) return;
    scaredOnce = true;

    var flash = document.createElement('div');
    flash.style.cssText = [
      'position:fixed', 'top:0', 'left:0', 'width:100%', 'height:100%',
      'z-index:99999', 'pointer-events:none',
      'display:flex', 'align-items:center', 'justify-content:center',
      'background:rgba(0,0,0,0)',
      'transition:background 0.04s'
    ].join(';');

    var eyes = document.createElement('img');
    eyes.src = 'assets/blinking_eyes.gif';
    eyes.style.cssText = [
      'width:55vw', 'max-width:460px', 'opacity:0',
      'filter:brightness(0.5) contrast(1.5)',
      'transition:opacity 0.03s'
    ].join(';');
    flash.appendChild(eyes);
    document.body.appendChild(flash);

    requestAnimationFrame(function () {
      flash.style.background = 'rgba(2,0,5,0.95)';
      eyes.style.opacity = '1';
    });
    setTimeout(function () {
      eyes.style.opacity = '0';
      flash.style.background = 'rgba(0,0,0,0)';
    }, 190);
    setTimeout(function () { flash.remove(); }, 600);
  }, { passive: true });


  /* ─────────────────────────────────────────
     6. KILL-LIST SHUDDER — one hard involuntary
        shiver when the outcome section appears
  ───────────────────────────────────────── */
  var shaken = false;
  var shakeStyle = document.createElement('style');
  shakeStyle.textContent = '@keyframes coldShiver{' +
    '0%{transform:translate(0,0)}' +
    '15%{transform:translate(-5px,2px)}' +
    '30%{transform:translate(4px,-4px)}' +
    '45%{transform:translate(-3px,5px)}' +
    '60%{transform:translate(5px,-3px)}' +
    '75%{transform:translate(-4px,4px)}' +
    '100%{transform:translate(0,0)}}';
  document.head.appendChild(shakeStyle);

  var killSection = document.querySelector('[data-view="group-outcome"]');
  if (killSection) {
    new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting && !shaken) {
        shaken = true;
        document.body.style.animation = 'coldShiver 0.5s ease';
        setTimeout(function () { document.body.style.animation = ''; }, 600);
      }
    }, { threshold: 0.45 }).observe(killSection);
  }


  /* ─────────────────────────────────────────
     7. OS NOTIFICATIONS — on echo section.
        Formatted like real OS alerts.
        The mundanity is the horror.
  ───────────────────────────────────────── */
  var notifQueue = [
    { app: 'Location Services',      msg: 'Your position shared with 12 third parties.' },
    { app: 'Analytics SDK',          msg: 'Emotional state logged — value: concerned.' },
    { app: 'Ad Exchange',            msg: 'Your attention sold. Bid price: $0.0034.' },
    { app: 'Face Recognition API',   msg: 'Identity confirmed. Profile merged.' },
    { app: 'Data Broker Network',    msg: 'Your record accessed by an unknown party.' },
  ];
  var notifShown = false;
  var echoSection = document.getElementById('echoSection');
  if (echoSection) {
    new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting && !notifShown) {
        notifShown = true;
        notifQueue.forEach(function (n, i) {
          setTimeout(function () {
            var el = document.createElement('div');
            el.style.cssText = [
              'position:fixed',
              'right:-480px',
              'top:' + (70 + i * 88) + 'px',
              'z-index:9991',
              'max-width:370px',
              'background:#0e0e15',
              'border:1px solid rgba(230,57,70,0.3)',
              'border-radius:10px',
              'padding:14px 18px',
              'font-family:"Share Tech Mono",monospace',
              'color:#9a9ab0',
              'font-size:1.2rem',
              'line-height:1.7',
              'box-shadow:0 4px 40px rgba(0,0,0,0.7)',
              'transition:right 0.55s cubic-bezier(0.22,1,0.36,1)',
            ].join(';');
            el.innerHTML =
              '<div style="font-size:1rem;color:rgba(230,57,70,0.55);letter-spacing:2px;margin-bottom:5px;text-transform:uppercase">' +
              n.app + '</div>' +
              '<div style="color:#c0c0cc">' + n.msg + '</div>';
            document.body.appendChild(el);
            requestAnimationFrame(function () { el.style.right = '20px'; });
            setTimeout(function () { el.style.right = '-480px'; }, 4500);
            setTimeout(function () { el.remove(); }, 5400);
          }, 1200 + i * 2800);
        });
      }
    }, { threshold: 0.2 }).observe(echoSection);
  }


  /* ─────────────────────────────────────────
     8. CAMERA TIMESTAMP — it never stops
  ───────────────────────────────────────── */
  var camTs = document.getElementById('camTs');
  if (camTs) {
    setInterval(function () {
      camTs.textContent = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
    }, 1000);
  }

})();
